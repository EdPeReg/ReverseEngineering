import string
import random
import sys

alphabet = string.ascii_lowercase

if len(sys.argv) <= 1:
    print("\nUsage: python3 keygen.py <number_of_keys_to_generate>\n")
else:
    nr_of_keys = int(sys.argv[1])
    for key in range(0,nr_of_keys):
        result_key = ''
        sum_ascii = 0
        counter = 1
        for index in range(0, 11):
            random_int = random.randint(0, len(alphabet)-1)
            random_char_alpabet = alphabet[random_int]
            ascii_random_char = ord(random_char_alpabet)
            result_key += random_char_alpabet
            sum_ascii += ascii_random_char
            if len(result_key) > 7 and len(result_key) < 11:
                if sum_ascii < 1000:
                    pass
                else:
                    print(key+1, " - ", result_key)
                    break



